from flask import Flask, render_template, request, jsonify, redirect

app = Flask(__name__)

nicknames = set()
registrace_data = []

def is_valid_nickname(nick):
    return nick.isalnum() and 2 <= len(nick) <= 20

@app.route('/api/check-nickname', methods=['GET'])
def check_nickname():
    nick = request.args.get('nick')
    if nick in nicknames:
        return jsonify({"exists": True})
    else:
        return jsonify({"exists": False})

@app.route('/', methods=['GET'])
def index():
    return render_template('prvni_stranka.html', ucastnici=registrace_data), 200

@app.route('/registrace', methods=['GET', 'POST'])
def registration():
    if request.method == 'GET':
        return render_template('registrace.html')
    if request.method == 'POST':
        data = request.form
        nick = data.get('nick')
        jmeno1 = data.get('jmeno1')
        prijmeni = data.get('prijmeni')
        trida = data.get('trida')
        je_plavec = data.get('je_plavec')
        kanoe_kamarad = data.get('kanoe_kamarad')

        if nick in nicknames:
            return jsonify({"error": "Tento nickname již existuje. Prosím, zvolte jiný."}), 400
        nicknames.add(nick)

        if je_plavec != 'Ano':
            return jsonify({"error": "Osoba musi byt plavec."}), 400

        if not is_valid_nickname(nick):
            return jsonify({"error": "Neplatny nick. Musi obsahovat anglicka pismena a cislice, a byt dlouhy 2-20 znaku."}), 400

        if not is_valid_nickname(jmeno1):
            return jsonify({"error": "Neplatne jmeno. Musi obsahovat anglicka pismena a cislice, a byt dlouhe 1-3 znaky."}), 400

        if not is_valid_nickname(prijmeni):
            return jsonify({"error": "Neplatne prijmeni. Musi obsahovat anglicka pismena a cislice, a byt dlouhe 1-3 znaky."}), 400

        if not is_valid_nickname(trida):
            return jsonify({"error": "Neplatna trida. Musi obsahovat anglicka pismena a cislice, a byt dlouha 1-3 znaky."}), 400

        if kanoe_kamarad and not is_valid_nickname(kanoe_kamarad):
            return jsonify({"error": "Neplatny kamarad na kanoji. Musi obsahovat anglicka pismena a cislice, a byt dlouhy 2-20 znaku."}), 400

        registrace_data.append({"nick": nick, "jmeno1": jmeno1, "prijmeni": prijmeni, "trida": trida, "je_plavec": je_plavec, "kanoe_kamarad": kanoe_kamarad})

        return redirect("/")









if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
